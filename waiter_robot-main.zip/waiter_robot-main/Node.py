from State import State


class Node:
    # Contains an State
    def __init__(self, state: State):
        self.state = state
